<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Cadastro</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-1">
	

	<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>


	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<?php 
	$_SESSION["quant"] = $_POST ["quant"];
	$_SESSION["precot"] = $_SESSION["preco"] * $_SESSION["quant"];
	?>
</head>
<body style="background-color: #D8D8D8;">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				
				</button>
				<a class="navbar-brand" href="#">
					<img src="img/p.png" width="35" style="margin-top: -5px;">
				</a>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li ><a href="index.php">Home <span class="sr-only">(current)</span></a></li>  
					<ul class="nav navbar-nav navbar-right">
						<li><a href="pag2.php">Produtos</a></li>
					</div><!-- /.navbar-collapse -->
				</div><!-- /.container-fluid -->
			</nav>
			
			<form action="desc.php" method="post">
				<div class="container text-justify mt-5">
					<div class="row">
						<div class="col">
							<div class="mb-3">
								<div class="row text-dark">
									<div class="col-md-5">
										<img src="img/<?php echo $_SESSION['imagem']; ?>" class="card-img" alt="<?php echo $_SESSION["nome"]; ?>">
									</div>
									<div class="col-md"></div>
									<div class="col-md-5">
										<div>
											<ul class="list-group">
												<li class="list-group-item">
													<strong class="h3 text-white"><?php echo $_SESSION["nome"]; ?></strong>
												</li>
												<li class="list-group-item">
													<strong>Preço Unitário:</strong>
													<span>
														<strong>R$ <?php echo $_SESSION["preco"]; ?></strong>
													</span>
												</li>
												<li class="list-group-item">
													<strong>Quantidade:</strong>
													<span>
														<strong><?php echo $_SESSION["quant"]; ?></strong>
													</span>
												</li>
												<li class="list-group-item">
													<strong>Preço Total:</strong>
													<span>
														<strong>R$ <?php echo $_SESSION["precot"]; ?></strong>
													</span>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col">
							<fieldset>
								<legend>Dados:</legend>
								<div>
									<div class="input-group-sm mb-3">
										<label>Nome: </label>
										<input type="text" class="form-control" name="pnome" required autofocus placeholder="Nome">
									</div>
									<div class="input-group-sm mb-3">
										<label>CPF: </label>
										<input type="text" class="form-control" name="cpf" required maxlength="14" placeholder="CPF">
									</div>
									<div class="input-group-sm mb-3">
										<label>E-mail: </label>
										<input type="email" class="form-control" name="email" required maxlength="100" placeholder="E-mail">
									</div>
									<div class="input-group-sm mb-3">
										<label>Celular: </label>
										<input type="tel" class="form-control" name="cel" required maxlength="14" placeholder="Celular">
									</div>
								</div>
							</fieldset>
						</div>
						<div class="col">
							<fieldset>
								<legend>Endereço:</legend>
								<div>
									<div class="input-group-sm mb-3">
										<label>Rua: </label>
										<input type="text" class="form-control" name="rua" required placeholder="Rua">
									</div>
									<div class="input-group-sm mb-3">
										<label>Número: </label>
										<input type="number" class="form-control" name="num" required placeholder="Número">
									</div>
									<div class="input-group-sm mb-3">
										<label>Complemento: </label>
										<input type="text" class="form-control" name="com" placeholder="Complemento">
									</div>
									<div >
										<div class="col-sm mb-3">
											<label>CEP: </label>
											<input type="text" class="form-control" name="cep" required maxlength="9" placeholder="CEP">
										</div>
										
										<div class="col-sm mb-3">
											<label>UF: </label>
											<select class="form-control" name="uf" required>
												<option selected>Selecione uma opção</option>
												<option value="AC">AC</option>
												<option value="AL">AL</option>
												<option value="AM">AM</option>
												<option value="AP">AP</option>
												<option value="BA">BA</option>
												<option value="CE">CE</option>
												<option value="DF">DF</option>
												<option value="ES">ES</option>
												<option value="GO">GO</option>
												<option value="MA">MA</option>
												<option value="MG">MG</option>
												<option value="MS">MS</option>
												<option value="MT">MT</option>
												<option value="PA">PA</option>
												<option value="PB">PB</option>
												<option value="PE">PE</option>
												<option value="PI">PI</option>
												<option value="PR">PR</option>
												<option value="RJ">RJ</option>
												<option value="RN">RN</option>
												<option value="RO">RO</option>
												<option value="RR">RR</option>
												<option value="RS">RS</option>
												<option value="SC">SC</option>
												<option value="SE">SE</option>
												<option value="SP">SP</option>
												<option value="TO">TO</option>
											</select>
										</div>
									</div>
								</div>
							</fieldset>
						</div>
					</div>
					<br>

					<div class="mt-4">
						<button type="submit" class="btn btn-success btn-block" name="final">Prosseguir</button>
					</div>
				</div>
			</from>
			
		</fieldset>
		<br><br>
		<div class="progress">
			<div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
				<!--span class="sr-only" -->70% completando!!!<!--/span -->
			</div>


		</body>
		</html>