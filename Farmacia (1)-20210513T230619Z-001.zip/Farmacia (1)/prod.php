<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Drogaria Molex - Produtos</title>
	<meta charset="utf-8">
	
	<meta name="viewport" content="width=device-width, initial-scale-1">
	

	<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>


	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

	<?php
	$prod = $_POST["prod"];
	$_SESSION["codigo"]=0;
	$_SESSION["nome"]="";
	$_SESSION["preco"]=0;
	$_SESSION["imagem"]="";
	$_SESSION["quantidade"]=0;

	$condb=new mysqli('localhost', 'root', '', 'molex');
	if ($prod=="Centrum (Homem)") {
		$cmd="SELECT * FROM tudo WHERE codigo='1'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Centrum (Mulher)") {
		$cmd="SELECT * FROM tudo WHERE codigo='2'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Eno") {
		$cmd="SELECT * FROM tudo WHERE codigo='3'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Eno (Laranja)") {
		$cmd="SELECT * FROM tudo WHERE codigo='4'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Eno (Abacaxi)") {
		$cmd="SELECT * FROM tudo WHERE codigo='5'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Buscopan") {
		$cmd="SELECT * FROM tudo WHERE codigo='6'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Dipirona (Gotas)") {
		$cmd="SELECT * FROM tudo WHERE codigo='7'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Doril") {
		$cmd="SELECT * FROM tudo WHERE codigo='8'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Dorflex") {
		$cmd="SELECT * FROM tudo WHERE codigo='9'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Anador") {
		$cmd="SELECT * FROM tudo WHERE codigo='10'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Cerumin") {
		$cmd="SELECT * FROM tudo WHERE codigo='11'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Fralda (Pampers)") {
		$cmd="SELECT * FROM tudo WHERE codigo='12'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Gel Anti-Séptico") {
		$cmd="SELECT * FROM tudo WHERE codigo='13'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Cicatricure") {
		$cmd="SELECT * FROM tudo WHERE codigo='14'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Nivea Sun") {
		$cmd="SELECT * FROM tudo WHERE codigo='15'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Nivea Men") {
		$cmd="SELECT * FROM tudo WHERE codigo='16'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Old-Space") {
		$cmd="SELECT * FROM tudo WHERE codigo='17'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}elseif ($prod=="Mucilon") {
		$cmd="SELECT * FROM tudo WHERE codigo='18'";
		$resul=$condb->query($cmd);
		while ($row=$resul->fetch_row()) {
			$_SESSION["codigo"]=$row[0];
			$_SESSION["nome"]=$row[1];
			$_SESSION["preco"]=$row[2];
			$_SESSION["imagem"]=$row[3];
			$_SESSION["quantidade"]=$row[4];
		}
	}
	?>
</head>
<body style="background-color: #848484;">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">
					<img src="img/p.png" width="35" style="margin-top: -5px;">
				</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li ><a href="index.php">Home <span class="sr-only">(current)</span></a></li>  
					<ul class="nav navbar-nav navbar-right">
						<li><a href="pag2.php">Produtos</a></li>
					</div>
				</div>
			</nav>
			<div class="container">
				<form class="mt-5" action="cad.php" method="post">
					<div class="row text-center">
						<div class="col">
							<img class="img-thumbnail" src="img/<?php echo $_SESSION['imagem']; ?>">
						</div>
						<div class="col">
							<ul class="list-group text-dark">
								<li class="list-group-item d-flex justify-content-between align-items-center bg-dark">
									<strong class="h5 text-white"><?php echo $_SESSION["nome"]; ?></strong>
								</li>
								<li class="list-group-item d-flex justify-content-between align-items-center">
									<strong>Valor:</strong>
									<span>
										<strong>R$ <?php echo $_SESSION["preco"]; ?></strong>
									</span>
								</li>
								<li class="list-group-item d-flex justify-content-between align-items-center">
									<strong>Em Estoque:</strong>
									<span>
										<strong><?php echo $_SESSION['quantidade']; ?></strong>
									</span>
								</li>
								<li class="list-group-item d-flex justify-content-between align-items-center">
									<strong>Quantidade:</strong>
									<span>
										<input class="form-control-sm" type='number' name='quant' min='1' max='<?php echo $_SESSION['quantidade']; ?>' required autofocus>
									</span>
								</li>
								<li class="list-group-item d-flex justify-content-between align-items-center">
									<button type="submit" class="btn btn-success btn-block" name="prod" value="<?php echo $_SESSION["nome"]; ?>">Comprar</button>
								</li>
							</ul>
						</div>
					</div>
				</form>

			</div>



		</body>
		</html>