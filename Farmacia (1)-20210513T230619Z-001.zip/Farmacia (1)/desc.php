<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Drogaria Molex - Confirma</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-1">
	<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<?php 
			
			$_SESSION["pnome"] = $_POST["pnome"];
			$_SESSION["cpf"] = $_POST["cpf"];
			$_SESSION["email"] = $_POST["email"];
			$_SESSION["cel"] = $_POST["cel"];
			$_SESSION["rua"] = $_POST["rua"];
			$_SESSION["num"] = $_POST["num"];
			$_SESSION["com"] = $_POST["com"];
			$_SESSION["cep"] = $_POST["cep"];
			$_SESSION["uf"] = $_POST["uf"];
 ?>
</head>
<body>
	<ul class="list-group">
		<img align="center" src="img/<?php echo $_SESSION['imagem']; ?>">
		<ul class="list-group">
												<li class="list-group-item">
													<strong class="h3 text-white"><?php echo $_SESSION["nome"]; ?></strong>
												</li>
												<li class="list-group-item">
													<strong>Preço Unitário:</strong>
													<span>
														<strong>R$ <?php echo $_SESSION["preco"]; ?></strong>
													</span>
												</li>
												<li class="list-group-item">
													<strong>Quantidade:</strong>
													<span>
														<strong><?php echo $_SESSION["quant"]; ?></strong>
													</span>
												</li>
												<li class="list-group-item">
													<strong>Preço Total:</strong>
													<span>
														<strong>R$ <?php echo $_SESSION["precot"]; ?></strong>
													</span>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
		<li class="list-group-item">
			<h2>Dados Pessoais</h2>
		
		<?php 
			echo "Nome: ";
			echo $_SESSION["pnome"]; ?>
		</li>
		<li class="list-group-item">

			<?php 
			echo "<strong>CPF</strong>: ";
			echo $_SESSION["cpf"]; ?>
		</li>
		<li class="list-group-item">
			
			<?php
			 echo "<strong>Email</strong>: ";
			 echo $_SESSION["email"]; ?>
		</li>
		<li class="list-group-item">
			

			<?php
			echo "<strong>Celular</strong>: ";
			 echo $_SESSION["cel"]; ?>
		</li>
		<li class="list-group-item">
			<?php
			echo "<strong>Rua</strong>: ";
			 echo $_SESSION["rua"]; ?>
		</li>
		<li class="list-group-item">
			<?php
			echo "<strong>Numero da Casa</strong>: ";
			 echo $_SESSION["num"]; ?>
		</li>
		<li class="list-group-item">
			<?php 
			echo "<strong>Complemento</strong>: ";
			echo $_SESSION["com"]; ?>
		</li>
		<li class="list-group-item">
			<?php 
			echo "<strong>CEP</strong>: ";
			echo $_SESSION["cep"]; ?>
		</li>
		<li class="list-group-item">
			<?php
			echo "<strong>UF</strong>: ";
			 echo $_SESSION["uf"]; ?>
		</li>
	</ul>
	<form action="pag2.php">
			<div class="mt-4">
						<button type="submit" class="btn btn-success btn-block" name="final">Continuar comprando</button>
					</div>
					</form>
					<br>
					<br>
					<form action="obrigado.php">
					<div class="mt-4">
						<button type="submit" class="btn btn-danger btn-block" name="final">Finalizar compra</button>
					</div>
				</form>
					
					<br><br>


</body>
</html>