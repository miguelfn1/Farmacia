<?php session_start();
$_SESSION["logado"] = "";
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Drogaria Molex</title>
	<meta charset="utf-8">
	
	<meta name="viewport" content="width=device-width, initial-scale-1">
	<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body style="background-color:#848484;">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">
					<img src="img/p.png" width="35" style="margin-top: -5px;">

				</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li ><a href="index.php">Home <span class="sr-only">(current)</span></a></li>  
					<ul class="nav navbar-nav navbar-right">
						<li><a href="pag2.php">Produtos</a></li>

						<ul class="nav navbar-nav navbar-right">
						<li><a href="login.php">Login</a></li>
						
					</div>
				</div>
			</nav>


			<div class="container" style="text-align: center; font-size: 40px;">


				<br>




				<div id="meu" class="carousel slide" data-ride="carousel" style="width: 1150px;">
					<ol class="carousel-indicators">
						<li data-target="#meu" data-slide-to="0" class="active"></li>
						<li data-target="#meu" data-slide-to="1"></li>
						<li data-target="#meu" data-slide-to="2"></li>
					</ol>


					<div class="carousel-inner">
						<div class="item active">
							<img src="img/b.jpg" alt="Farmacia">
						</div>
						<div class="item">
							<img src="img/c.jpg" alt="Farmacia">
						</div>
						<div class="item">
							<img src="img/d.jpg" alt="Farmacia">
						</div>
					</div>

					<a href="#meu" class="left carousel-control" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
					<a href="#meu" class="right carousel-control" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
				</div>




				<br><br>

			</div>

			<iframe src="text.php" name="conteudo"
			height="500" width="700" frameborder="0" style="margin-left: 350px;"></iframe>






		</body>
		</html>