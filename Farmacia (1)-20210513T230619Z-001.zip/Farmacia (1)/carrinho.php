<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Drogaria Mole-x - Carrinho</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-1">
	<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">
					<img src="img/p.png" width="35" style="margin-top: -5px;">

				</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li ><a href="index.php">Home <span class="sr-only">(current)</span></a></li>  
					<ul class="nav navbar-nav navbar-right">
						<li><a href="pag2.php">Produtos</a></li>

					
						
					</div>
				</div>
			</nav>

				<br>


	
<img align="center" src="img/<?php echo $_SESSION['imagem']; ?>">
<form action="limpa.php">
	
	<button type="submit" class="btn btn-danger " name="final" style="margin-left:1000px;">Limpar Carrinho</button>
	</form>
	<br><br>
	
		<ul class="list-group">
												<li class="list-group-item">
													<strong class="h3 text-white"><?php echo $_SESSION["nome"]; ?></strong>
												</li>
												<li class="list-group-item">
													<strong>Preço Unitário:</strong>
													<span>
														<strong>R$ <?php echo $_SESSION["preco"]; ?></strong>
													</span>
												</li>
												<li class="list-group-item">
													<strong>Quantidade:</strong>
													<span>
														<strong><?php echo $_SESSION["quant"]; ?></strong>
													</span>
												</li>
												<li class="list-group-item">
													<strong>Preço Total:</strong>
													<span>
														<strong>R$ <?php echo $_SESSION["precot"]; ?></strong>
													</span>
												</li>
											</ul>
					
			<h2>Dados Pessoais</h2>
		<li class="list-group-item">
					<?php 
			echo "<strong> Nome: ";
			echo $_SESSION["pnome"]; ?>
		</li>
		<li class="list-group-item">
			<?php
			echo "<strong>Rua</strong>: ";
			 echo $_SESSION["rua"]; ?>
		</li>
		<li class="list-group-item">
			<?php
			echo "<strong>Numero da Casa</strong>: ";
			 echo $_SESSION["num"]; ?>
		</li>
		<li class="list-group-item">
			<?php 
			echo "<strong>Complemento</strong>: ";
			echo $_SESSION["com"]; ?>
		</li>
		<li class="list-group-item">
			<?php 
			echo "<strong>CEP</strong>: ";
			echo $_SESSION["cep"]; ?>
		</li>
		<li class="list-group-item">
			<?php
			echo "<strong>UF</strong>: ";
			 echo $_SESSION["uf"]; ?>
		</li>
	</ul>



<br><br>
	<form action="obrigado.php">
					<div class="col-sm-3">
						<button type="submit" class="btn btn-success" name="final" style="margin-left: 980px;">Finalizar compra</button>
					</div>
				</form>
</div>
</body>
</html>