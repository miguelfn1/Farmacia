<?php  session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Compra-Finalizada</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-1">
	

	<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>


	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #848484; color: white;">
	<?php
	
	$quantfinal = $_SESSION["quantidade"] - $_SESSION["quant"];
	$cod = $_SESSION["codigo"]; 

	//Criar minha conexão
	$condb = new mysqli( 'localhost', 'root', '', 'molex');


	// sql to update a record
		 $_SESSION["nome"];
		 $_SESSION["cpf"];
		 $_SESSION["email"];
	 	 $_SESSION["cel"];
		 $_SESSION["rua"];
		 $_SESSION["com"];
		 $_SESSION["cep"];
	 	 $_SESSION["uf"];
	$sql = "UPDATE tudo SET quantidade= $quantfinal  WHERE codigo=$cod";
	
	if ($condb->query($sql) == true) {
		

	
	}
	?>

	
	<h1>Sua compra foi realizada com sucesso!!!!</h1>
	
	
	 <form action="pag2.php">
		<button style="color: black;">Voltar Para Produtos</button>
	</form>

				<div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%; position: fixed-bottom;">
					<!--span class="sr-only" -->100%!!!<!--/span -->
				</div>
		
</body>
</html>