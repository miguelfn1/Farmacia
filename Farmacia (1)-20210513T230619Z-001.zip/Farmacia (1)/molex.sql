-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 22-Jul-2019 às 20:29
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `molex`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tudo`
--

CREATE TABLE `tudo` (
  `codigo` int(4) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `preco` decimal(5,2) NOT NULL,
  `imagem` varchar(30) NOT NULL,
  `quantidade` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tudo`
--

INSERT INTO `tudo` (`codigo`, `nome`, `preco`, `imagem`, `quantidade`) VALUES
(1, 'Centrum (Homem)', '220.00', '1.png', 21),
(2, 'Centrum (Mulher)', '220.00', '2.png', 21),
(3, 'Eno', '10.00', '3.png', 73),
(4, 'Eno (Laranja)', '11.00', '4.png', 15),
(5, 'Eno (Abacaxi)', '11.00', '5.png', 5),
(6, 'Buscopan', '18.00', '6.png', 7),
(7, 'Dipirona (Gotas)', '8.00', '7.png', 10),
(8, 'Doril', '13.00', '8.png', 15),
(9, 'Dorflex', '14.00', '9.png', 15),
(10, 'Anador', '10.00', '10.png', 35),
(11, 'Cerumin', '11.00', '11.png', 21),
(12, 'Fralda (Pampers)', '52.00', '12.png', 47),
(13, 'Gel Anti-SÃ©ptico', '17.00', '13.png', 27),
(14, 'Cicatricure', '22.00', '14.png', 25),
(15, 'Nivea Sun', '23.00', '15.png', 25),
(16, 'Nivea Men', '12.50', '16.png', 25),
(17, 'Old-Space', '16.70', '17.png', 25),
(18, 'Mucilon', '21.30', '18.png', 8);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `login` varchar(20) NOT NULL,
  `senha` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas`
--

CREATE TABLE `vendas` (
  `nome` varchar(50) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `email` varchar(90) NOT NULL,
  `cel` varchar(10) NOT NULL,
  `rua` varchar(50) NOT NULL,
  `num` varchar(10) NOT NULL,
  `com` varchar(100) NOT NULL,
  `cep` varchar(9) NOT NULL,
  `uf` char(2) NOT NULL,
  `codvenda` int(11) NOT NULL,
  `codproduto` int(11) NOT NULL,
  `codcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tudo`
--
ALTER TABLE `tudo`
  ADD PRIMARY KEY (`codigo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
