<!DOCTYPE html>
<html>
<head>
	<title> Drogaria Molex - Produtos</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-1">
	<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>
<body style="background-color: #848484;">
	<?php 
	$condb=new mysqli('localhost', 'root', '', 'molex');

	 ?>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">
					<img src="img/p.png" width="35" style="margin-top: -5px;">
				</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>  
					<ul class="nav navbar-nav navbar-right">
						<li><a href="pag2.php">Produtos</a></li>
						<li><a href="carrinho.php"><img src="img/carro2.png" style="margin-top: -5px;"></a></li>
					</div>
				</div>
			</nav>
			
			<div class="container" style="text-align: center; color: white;">
				<h1>Drogaria Mole-X</h1>
				<p>Produtos</p>
				<br><br>
				<ul class="pagination">
					<li><a href="pag2.php">1</a></li>
					<li><a href="pag3.php" class="active">2</a></li>
					
				</ul>
				<form action="prod.php" method="post">
					<?php 
					for ($i=11; $i <19 ; $i++) { 
				$cmd="SELECT * FROM tudo WHERE codigo='$i'";
				$resul=$condb->query($cmd); 
				while ($row=$resul->fetch_row()) {
						
						$_SESSION["nome"]=$row[1];
						$_SESSION["preco"]=$row[2];
						$_SESSION["imagem"]=$row[3];
						echo "<div class='col-sm-6'>
							<img src='img/".$_SESSION["imagem"]."' alt='".$_SESSION["nome"]."' width='300' class='img-circle'>
							<p>".$_SESSION["nome"]."</p>
							<p>R$ ".$_SESSION["preco"]."</p>
							<button class='btn btn-info' name='prod' value='".$_SESSION["nome"]."'>Comprar</button>
						</div>
						<br>";
						
				}
					}

					 ?>
					
					</form>
					<p>&nbsp;</p>
					<p>&nbsp;</p>
					<p>&nbsp;</p>
					


				</div>
			</div>

		</body>
		</html>